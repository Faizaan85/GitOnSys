
-- --------------------------------------------------------

--
-- Table structure for table `equipment_master`
--

CREATE TABLE `equipment_master` (
  `id_equipment` int(10) UNSIGNED NOT NULL,
  `equip_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `equipment_master`:
--

--
-- Dumping data for table `equipment_master`
--

INSERT INTO `equipment_master` VALUES
(6, 'FENDER'),
(2, 'FRONT BUMPER'),
(7, 'GRILLE'),
(4, 'HEAD LAMP'),
(5, 'RADIATOR'),
(3, 'REAR BUMPER'),
(1, 'TAIL LAMP'),
(6, 'FENDER'),
(2, 'FRONT BUMPER'),
(7, 'GRILLE'),
(4, 'HEAD LAMP'),
(5, 'RADIATOR'),
(3, 'REAR BUMPER'),
(1, 'TAIL LAMP');
