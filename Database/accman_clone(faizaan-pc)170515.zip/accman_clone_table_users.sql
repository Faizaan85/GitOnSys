
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UsrId` int(11) NOT NULL,
  `UsrName` varchar(255) NOT NULL,
  `UsrEmail` varchar(255) NOT NULL,
  `UsrUsername` varchar(255) NOT NULL,
  `UsrPassword` varchar(255) NOT NULL,
  `UsrLevel` tinyint(4) NOT NULL DEFAULT '0',
  `UsrStoreLevel` enum('All','Store 1','Store 2') NOT NULL DEFAULT 'All'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES
(1, 'Faizaan Varteji', 'faizaan@carryonauto.com', 'faizaan85', '827ccb0eea8a706c4c34a16891f84e7b', 10, 'All'),
(3, 'faizaan varteji', 'faizaan.varteji@gmail.com', 'fz85', '827ccb0eea8a706c4c34a16891f84e7b', 1, 'All'),
(4, 'test1', 'test@test.com', 'test', '202cb962ac59075b964b07152d234b70', 0, 'Store 1');
