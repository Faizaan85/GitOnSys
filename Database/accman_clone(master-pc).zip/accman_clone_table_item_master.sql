
-- --------------------------------------------------------

--
-- Table structure for table `item_master`
--

DROP TABLE IF EXISTS `item_master`;
CREATE TABLE `item_master` (
  `id_item` int(10) UNSIGNED NOT NULL,
  `id_supplier` int(10) UNSIGNED DEFAULT NULL,
  `part_no` varchar(10) NOT NULL,
  `equipment` varchar(45) DEFAULT NULL,
  `description` varchar(250) NOT NULL,
  `year_from` int(2) UNSIGNED DEFAULT NULL,
  `year_to` int(2) UNSIGNED DEFAULT NULL,
  `multisided` tinyint(1) DEFAULT '0',
  `unit` varchar(3) DEFAULT NULL,
  `pkg_qty` int(2) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `isdelete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item_master`
--

INSERT INTO `item_master` VALUES
(1, NULL, 'TZ1187', 'TAIL LAMP', 'CAMRY TAIL LAMP', 9, 11, 1, 'PCS', 1, '1.50', 0),
(2, NULL, 'DT3802T', 'FRONT BUMPER', '720 FR BUMPER 4WD FORTUNER 3000CC', 6, NULL, 0, 'PCS', 1, '2.57', 0);
