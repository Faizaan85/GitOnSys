
-- --------------------------------------------------------

--
-- Table structure for table `orderitems1`
--

CREATE TABLE `orderitems1` (
  `OiId` int(11) NOT NULL,
  `OiOmId` int(11) NOT NULL,
  `OiPartNo` varchar(15) NOT NULL,
  `OiSupplierNo` varchar(15) NOT NULL,
  `OiDescription` varchar(100) NOT NULL,
  `OiLeftQty` int(10) UNSIGNED DEFAULT '0',
  `OiRightQty` int(10) UNSIGNED DEFAULT '0',
  `OiTotalQty` int(11) NOT NULL,
  `OiPrice` decimal(8,2) NOT NULL,
  `OiCreatedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `OiModifiedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `OiStatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: pending, 1: ready, 2: deleted'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `orderitems1`:
--
