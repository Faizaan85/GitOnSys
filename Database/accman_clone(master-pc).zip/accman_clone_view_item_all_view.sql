
-- --------------------------------------------------------

--
-- Structure for view `item_all_view`
--
DROP TABLE IF EXISTS `item_all_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root2`@`%` SQL SECURITY DEFINER VIEW `item_all_view`  AS  select `i`.`id_item` AS `id_item`,`i`.`part_no` AS `part_no`,`d`.`side` AS `side`,concat(`i`.`part_no`,`d`.`side`) AS `full_no`,`d`.`oem_no` AS `oem_no`,`d`.`supplier_no` AS `supplier_no`,`i`.`equipment` AS `equipment`,`i`.`description` AS `description`,`i`.`year_from` AS `year_from`,`i`.`year_to` AS `year_to`,`i`.`unit` AS `unit`,`d`.`unit_cost` AS `unit_cost`,`d`.`sales_price` AS `sales_price`,`d`.`qty_hand` AS `stock`,`d`.`max_level` AS `max_level`,`d`.`min_level` AS `min_level`,`i`.`pkg_qty` AS `pkg_qty`,`i`.`weight` AS `weight` from (`item_master` `i` join `item_details` `d`) where ((`d`.`id_item` = `i`.`id_item`) and (`i`.`isdelete` = 0)) ;
