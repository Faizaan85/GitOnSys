
-- --------------------------------------------------------

--
-- Table structure for table `ordermaster`
--

CREATE TABLE `ordermaster` (
  `OmId` int(11) NOT NULL,
  `OmCompanyName` varchar(150) NOT NULL,
  `OmCreatedOn` date DEFAULT NULL,
  `OmLpo` varchar(45) DEFAULT NULL,
  `OmStatus` tinyint(1) NOT NULL DEFAULT '0',
  `OmStore1` tinyint(4) NOT NULL DEFAULT '0',
  `OmStore2` tinyint(4) NOT NULL DEFAULT '0',
  `OmCreatedBy` int(11) NOT NULL DEFAULT '1',
  `OmPrinted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `ordermaster`:
--   `OmCreatedBy`
--       `users` -> `UsrId`
--

--
-- Dumping data for table `ordermaster`
--

INSERT INTO `ordermaster` VALUES
(1, 'MR. WALEED OMAN', '2017-04-22', '', 0, 0, 0, 3, 0),
(44, 'c to c', '2017-03-26', '', 0, 0, 0, 1, 0),
(48, 'speed', '2017-04-03', 'way', 0, 0, 0, 1, 0),
(49, 'speedway', '2017-04-03', 'someone', 0, 0, 0, 1, 0),
(50, 'speedway', '2017-04-03', 'uni', 0, 0, 0, 1, 0),
(51, 'speedway', '2017-04-03', 'uniw', 0, 0, 0, 1, 0),
(52, 'Speedway', '2017-04-03', 'uniworld-saeed', 0, 0, 0, 1, 0),
(53, 'Test', '2017-04-03', 'uniworld-saeed', 0, 0, 0, 1, 0),
(54, 'testing cash', '2017-04-03', '928347293487', 0, 0, 0, 1, 0),
(55, 'another test', '2017-04-03', 'lets see', 0, 0, 0, 1, 0),
(56, 'alert dismiss', '2017-04-03', 'dismissed', 0, 0, 0, 1, 0),
(57, 'sadiq ali general trading', '2017-04-04', 'MCK', 0, 0, 0, 1, 0),
(58, 'rocket', '2017-04-04', '', 0, 0, 0, 1, 0),
(59, 'yahya', '2017-04-04', 'cash', 0, 0, 0, 1, 0),
(60, 'fast world', '2017-04-04', '', 0, 0, 0, 1, 0),
(61, 'hariri cash', '2017-04-04', '0527620922', 0, 0, 0, 1, 0),
(62, 'ultimate', '2017-04-04', '', 0, 0, 0, 1, 0),
(63, 'halfords cash', '2017-04-04', '0507592698', 0, 0, 0, 1, 0),
(64, 'SPEEDWAY', '2017-04-05', 'moin', 0, 0, 1, 1, 0),
(65, 'SPEEDWAY ', '2017-04-05', 'moin', 0, 0, 0, 1, 0),
(66, 'SPEEDWAY', '2017-04-05', 'hashim', 0, 0, 0, 1, 0),
(67, 'SPEEDWAY', '2017-04-05', 'hashim', 0, 0, 0, 1, 0),
(68, 'SOMETHING', '2017-04-05', 'hello', 0, 0, 0, 1, 0),
(105, 'TOP CAR AUTO PARTS AND ACCESSORIES L.L.C', '2017-04-12', '', 0, 0, 1, 1, 0),
(106, 'ASDFASDF', '2017-04-13', 'ASDF', 0, 0, 0, 1, 0),
(107, 'MR. WALEED OMAN', '2017-04-13', '', 1, 0, 0, 1, 0),
(108, 'TOP CAR AUTO PARTS AND ACCESSORIES L.L.C', '2017-04-13', '', 0, 0, 0, 1, 0),
(109, 'TOP CAR AUTO PARTS AND ACCESSORIES L.L.C', '2017-04-16', 'QUOTATION', 0, 0, 0, 1, 0),
(110, 'CASH CUSTOMER APRIL 2017', '2017-04-18', 'MOHAN NEPAL', 0, 0, 0, 1, 0),
(111, 'LANDMARK AUTO PARTS LLC', '2017-04-18', 'PRAVEEN', 1, 0, 0, 1, 1),
(112, 'MR. WALEED OMAN', '2017-04-22', '', 1, 0, 0, 3, 1),
(113, '**BENGAL AUTO PARTS', '2017-04-22', 'lkjlk', 1, 1, 1, 1, 1),
(114, 'AL AHARAR AUTO PARTS', '2017-05-06', 'TESTING', 0, 0, 0, 1, 0),
(115, 'POPULAR AUTO PARTS', '2017-05-06', 'TESTING', 0, 0, 0, 1, 0),
(116, '**BENGAL AUTO PARTS', '2017-05-06', 'TESTING AGAIN', 0, 0, 0, 1, 0),
(117, 'MR. WALEED OMAN', '2017-05-06', '', 0, 0, 0, 1, 0),
(118, 'AL BAGDADI AUTO SPARE PARTS CO', '2017-05-06', 'TESTING', 0, 0, 0, 1, 0),
(119, 'MR. WALEED OMAN', '2017-05-06', 'TEST', 0, 0, 0, 1, 0),
(120, 'SIGNAL AUTO PARTS', '2017-05-06', 'TEST', 0, 0, 0, 1, 0),
(121, 'MR. WALEED OMAN', '2017-05-06', '', 0, 0, 0, 1, 0),
(122, 'MR. WALEED OMAN', '2017-05-06', 'TESTING', 0, 0, 0, 1, 0),
(123, 'MR. WALEED OMAN', '2017-05-06', '', 0, 0, 0, 1, 0),
(124, 'MR. WALEED OMAN', '2017-05-06', '', 0, 0, 0, 1, 0),
(125, 'MR. WALEED OMAN', '2017-05-06', 'TESTING', 0, 0, 1, 1, 0),
(126, 'WOOD LAND AUTO PARTS', '2017-05-06', 'TEST', 0, 0, 1, 1, 0);
