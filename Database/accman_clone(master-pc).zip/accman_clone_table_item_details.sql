
-- --------------------------------------------------------

--
-- Table structure for table `item_details`
--

DROP TABLE IF EXISTS `item_details`;
CREATE TABLE `item_details` (
  `id_itemdetails` int(10) UNSIGNED NOT NULL,
  `id_item` int(10) UNSIGNED NOT NULL,
  `side` varchar(1) DEFAULT NULL,
  `oem_no` varchar(30) DEFAULT NULL,
  `supplier_no` varchar(30) DEFAULT NULL,
  `unit_cost` decimal(6,2) DEFAULT NULL,
  `sales_price` decimal(6,2) DEFAULT NULL,
  `qty_hand` int(10) UNSIGNED DEFAULT NULL,
  `max_level` int(10) UNSIGNED DEFAULT NULL,
  `min_level` int(10) UNSIGNED DEFAULT NULL,
  `qty_order` int(10) UNSIGNED DEFAULT NULL,
  `open_stock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item_details`
--

INSERT INTO `item_details` VALUES
(1, 1, 'L', '81561-06440', '212-19T9L-U', '110.70', '140.00', 75, 1000, 25, NULL, 75),
(2, 1, 'R', '81561-06441', '212-19T9R-U', '110.70', '140.00', 20, 500, 10, NULL, 20),
(4, 2, 'N', '62022VK325/300', 'DS04225BAS', '78.75', '140.00', 28, 200, 10, NULL, 28);
