
-- --------------------------------------------------------

--
-- Table structure for table `stud`
--

CREATE TABLE `stud` (
  `roll_no` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `stud`:
--

--
-- Dumping data for table `stud`
--

INSERT INTO `stud` VALUES
(NULL, NULL),
(2, 'Brian'),
(3, 'Charlie'),
(NULL, NULL),
(2, 'Brian'),
(3, 'Charlie');
