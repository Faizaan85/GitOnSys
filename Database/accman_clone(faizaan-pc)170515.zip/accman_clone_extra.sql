
--
-- Indexes for dumped tables
--

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`PART_NO`);

--
-- Indexes for table `itemdetails`
--
ALTER TABLE `itemdetails`
  ADD PRIMARY KEY (`IdId`),
  ADD UNIQUE KEY `partno` (`IdIPART_NO`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`OiId`);

--
-- Indexes for table `ordermaster`
--
ALTER TABLE `ordermaster`
  ADD PRIMARY KEY (`OmId`),
  ADD KEY `OmCreatedBy` (`OmCreatedBy`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UsrId`),
  ADD UNIQUE KEY `usr_email` (`UsrEmail`),
  ADD UNIQUE KEY `usr_username` (`UsrUsername`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itemdetails`
--
ALTER TABLE `itemdetails`
  MODIFY `IdId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8192;
--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `OiId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=996;
--
-- AUTO_INCREMENT for table `ordermaster`
--
ALTER TABLE `ordermaster`
  MODIFY `OmId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UsrId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `itemdetails`
--
ALTER TABLE `itemdetails`
  ADD CONSTRAINT `Fkey_PartNo` FOREIGN KEY (`IdIPART_NO`) REFERENCES `item` (`PART_NO`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `ordermaster`
--
ALTER TABLE `ordermaster`
  ADD CONSTRAINT `fkey_userid` FOREIGN KEY (`OmCreatedBy`) REFERENCES `users` (`UsrId`) ON DELETE CASCADE ON UPDATE CASCADE;
