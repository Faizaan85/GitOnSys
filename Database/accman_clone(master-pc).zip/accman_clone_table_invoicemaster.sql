
-- --------------------------------------------------------

--
-- Table structure for table `invoicemaster`
--

DROP TABLE IF EXISTS `invoicemaster`;
CREATE TABLE `invoicemaster` (
  `ImId` int(10) UNSIGNED NOT NULL,
  `OmId` int(11) NOT NULL,
  `CLCODE` varchar(6) NOT NULL,
  `ImDiscount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ImtotalAmount` decimal(10,2) NOT NULL COMMENT 'Amount after discount',
  `UsrId` int(11) NOT NULL,
  `ImMessage` varchar(300) DEFAULT NULL,
  `ImCreatedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ImModifiedOn` timestamp NULL DEFAULT NULL,
  `ImIsDelete` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
